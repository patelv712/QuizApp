//
//  newAppApp.swift
//  newApp
//
//  Created by Neha Lalani on 9/27/22.
//

import SwiftUI

@main
struct newAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
