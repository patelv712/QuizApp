//
//  SwiftUIView.swift
//  newApp
//
//  Created by Neha Lalani on 9/29/22.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        Text("Can this be page 2?")
    
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIView()
    }
}
